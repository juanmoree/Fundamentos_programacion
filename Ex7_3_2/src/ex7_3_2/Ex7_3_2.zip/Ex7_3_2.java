package ex7_3_2;

import java.util.Scanner;

public class Ex7_3_2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Introduce una palabra");
		
		String palabra = sc.nextLine();
		String alreves = "";
		int length = palabra.length();

		for (int i = length; i > 0; i--) {
			alreves += palabra.charAt(i - 1);
		}
		System.out.println(alreves);

		sc.close();
	}

}
