package ex7_1_5;

public class Ex7_1_5 {

	public static void main(String[] args) {

		for (int i = 100; i >= 0; i -= 2) {
			System.out.print(i + " ");
		}
	}
}
